#ifndef REAL_TIME_HANDLER_H
#define REAL_TIME_HANDLER_H

#include <pthread.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Thread pour la compression en temps réel.
 * Cette fonction sera appelée dans un thread pour effectuer la compression de manière asynchrone.
 * 
 * @param arg Argument passé au thread (par exemple, le chemin du fichier à compresser).
 * @return Un pointeur vers le résultat du thread (NULL par défaut).
 */
void *compression_thread(void *arg);

/**
 * Thread pour la décompression en temps réel.
 * Cette fonction sera appelée dans un thread pour effectuer la décompression de manière asynchrone.
 * 
 * @param arg Argument passé au thread (par exemple, le chemin du fichier à décompresser).
 * @return Un pointeur vers le résultat du thread (NULL par défaut).
 */
void *decompression_thread(void *arg);

#ifdef __cplusplus
}
#endif

#endif // REAL_TIME_HANDLER_H
