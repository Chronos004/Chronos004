#ifndef COMPRESSOR_H
#define COMPRESSOR_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Fonction pour compresser les données.
 * Cette fonction prend en entrée un bloc de données et le compresse dans un format spécifié.
 * 
 * @param input Données à compresser.
 * @param output Buffer où stocker les données compressées.
 * @param input_size Taille des données à compresser.
 * @param max_output_size Taille maximale du buffer de sortie.
 * @return La taille des données compressées ou une valeur négative en cas d'erreur.
 */
int compress_data(const char *input, char *output, size_t input_size, size_t max_output_size);

#ifdef __cplusplus
}
#endif

#endif // COMPRESSOR_H
