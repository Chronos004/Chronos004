#ifndef DECOMPRESSOR_H
#define DECOMPRESSOR_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Fonction pour décompresser les données.
 * Cette fonction prend en entrée un bloc de données compressées et le décompresse.
 * 
 * @param input Données compressées.
 * @param output Buffer où stocker les données décompressées.
 * @param compressed_size Taille des données compressées.
 * @param max_output_size Taille maximale du buffer de décompression.
 * @return La taille des données décompressées en cas de succès, ou une valeur négative en cas d'erreur.
 */
int decompress_data(const char *input, char *output, size_t compressed_size, size_t max_output_size);

#ifdef __cplusplus
}
#endif

#endif // DECOMPRESSOR_H
