#include <stdio.h>
#include <stdlib.h>
#include <lz4.h>
#include "decompressor.h"

int decompress_data(const char *input, char *output, int compressed_size, int max_output_size) {
    return LZ4_decompress_safe(input, output, compressed_size, max_output_size);
}
