#include <stdio.h>
#include <stdlib.h>
#include <lz4.h>
#include "compressor.h"

int compress_data(const char *input, char *output, int input_size) {
    return LZ4_compress_default(input, output, input_size, input_size * 2);
}
