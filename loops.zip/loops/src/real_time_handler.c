#include <pthread.h>
#include <stdio.h>
#include "real_time_handler.h"
#include "compressor.h"
#include "decompressor.h"

void *compression_thread(void *arg) {
    // Implémentation du thread pour la compression en temps réel
    // ...
}
