import ctypes

# Charger la bibliothèque partagée
compressor_lib = ctypes.CDLL('./build/libcompressor.so')

def compress_data(input_data):
    output_data = ctypes.create_string_buffer(len(input_data) * 2)
    size = compressor_lib.compress_data(input_data, output_data, len(input_data))
    return output_data.raw[:size]

def decompress_data(input_data):
    output_data = ctypes.create_string_buffer(len(input_data) * 2)
    size = compressor_lib.decompress_data(input_data, output_data, len(input_data))
    return output_data.raw[:size]
