from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget
from src.bindings import compress_data, decompress_data

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Compression en Temps Réel")
        self.setGeometry(100, 100, 400, 200)

        self.layout = QVBoxLayout()
        self.compress_button = QPushButton("Démarrer la Compression")
        self.compress_button.clicked.connect(self.start_compression)
        self.layout.addWidget(self.compress_button)

        self.status_label = QLabel("Statut : En attente")
        self.layout.addWidget(self.status_label)

        container = QWidget()
        container.setLayout(self.layout)
        self.setCentralWidget(container)

    def start_compression(self):
        # Exemple d'utilisation
        test_data = "Données à compresser"
        compressed = compress_data(test_data)
        decompressed = decompress_data(compressed)
        self.status_label.setText("Compression et Décompression terminées")

if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()
